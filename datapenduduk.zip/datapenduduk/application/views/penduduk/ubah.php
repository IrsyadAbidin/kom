 value="<?= $siswa['id']; ?>">
 <div class="container">
    <?= form_open_multipart('penduduk/tambah');?>
        <legend>Tambah Data penduduk</legend>
        <div class="mb-3">
            <label for="nik" class="form-label">NIK</label>
            <input type="text" class="form-control" id="nik" name="nik" style="width : 500px;" value="<?= $penduduk['nik']; ?>">>
            <div class="form-text text-danger"><?= form_error('nik'); ?></div>
        </div>
        <div class="mb-3">
            <label for="formFile" class="form-label">Foto</label>
            <input class="form-control" type="file" id="formFile" name="image" style="width : 500px;"value="<?= $penduduk['foto']; ?>">>
            <div class="form-text text-danger"><?= form_error('image'); ?></div>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;"value="<?= $penduduk['nama']; ?>">>
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="bansos" class="form-label">bansos</label>
            <select class="form-select" id="bansos" name="bansos" style="width : 500px;"value="<?= $penduduk['bansos']; ?>">>
                <option selected>Pilih Bansos</option>
            <?php foreach( $bansos as $ban ) : ?>
                <option value="<?= $ban['id']; ?>"><?= $ban['bansos']; ?></option>
            <?php endforeach; ?>
            </select>
            <div class="form-text text-danger"><?= form_error('bansos'); ?></div>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" style="width : 500px;"value="<?= $penduduk['email']; ?>">>
            <div class="form-text text-danger"><?= form_error('email'); ?></div>
        </div>
        <div class="mb-3">
            <label for="hp" class="form-label">Hp</label>
            <input type="text" class="form-control" id="hp" name="hp" style="width : 500px;"value="<?= $penduduk['hp']; ?>">>
            <div class="form-text text-danger"><?= form_error('hp'); ?></div>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" style="width : 500px;"><?= $penduduk['alamat']; ?>"></textarea>
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div>
        <input type="submit" value="Ubah" class="btn btn-primary"></input>
    </form>
</div>

